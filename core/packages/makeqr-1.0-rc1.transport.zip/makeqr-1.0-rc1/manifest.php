<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => 'makeQR - Uses google chart api to make QR codes.

https://code.google.com/apis/chart/docs/gallery/qr_codes.html

QR codes are handy way to get a link from your computer to your mobile phone. Generate 2D barcodes containing a website URL, an email address, a phone number, a pre-formatted SMS message or just plain text.',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'ba036ee8f28baf3a9b448dc26645e754',
      'native_key' => 'makeqr',
      'filename' => 'modNamespace/2c9f06eafcb2979a1dea98045cfaa9dc.vehicle',
      'namespace' => 'makeqr',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'a06bfe7f395b954c561be38b4a50e737',
      'native_key' => 1,
      'filename' => 'modCategory/ab7063b42a2dcfe421efee4a393c6419.vehicle',
      'namespace' => 'makeqr',
    ),
  ),
);