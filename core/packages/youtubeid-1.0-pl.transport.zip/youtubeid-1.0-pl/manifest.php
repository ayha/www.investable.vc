<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '// Read ME //
YouTubeId output modifier

usage:

[[*TVYouTubeURL:getYouTubeId]]
returns the youtube ID for the supplied youtube URL
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '59a2e63e5fc907f04e424f92f2f3deaa',
      'native_key' => 'youtubeid',
      'filename' => 'modNamespace/29d92d6546505f2f9c0865fab85808a7.vehicle',
      'namespace' => 'youtubeid',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'a424e550408d43efb0d37795a6e1153c',
      'native_key' => 1,
      'filename' => 'modCategory/8e252b069562477b73a160d684c09c9b.vehicle',
      'namespace' => 'youtubeid',
    ),
  ),
);