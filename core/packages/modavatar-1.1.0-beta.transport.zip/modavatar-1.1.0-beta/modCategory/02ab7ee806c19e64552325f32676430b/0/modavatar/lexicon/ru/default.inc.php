<?php

$_lang['modavatar'] = "modAvatar";
$_lang['modavatar.select_file'] = "Выбрать файл";
?>
