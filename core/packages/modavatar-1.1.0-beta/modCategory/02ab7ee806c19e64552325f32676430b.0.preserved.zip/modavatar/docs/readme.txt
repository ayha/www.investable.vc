modAvatar allow to update user profile photo via adminpanel (manager)

Note! If you set another Media source than default, use modAvatar snippet for
get correct path.