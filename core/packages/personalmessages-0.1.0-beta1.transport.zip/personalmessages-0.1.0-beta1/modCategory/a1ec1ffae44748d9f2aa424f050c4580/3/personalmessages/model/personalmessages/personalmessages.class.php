<?php
class PersonalMessages {
    function helloworld() {
        return 'Hello World';
    }
}                                                                   